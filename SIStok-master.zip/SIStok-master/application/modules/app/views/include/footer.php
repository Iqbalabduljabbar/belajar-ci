            <footer class="well">
                <p><?php echo $credit; ?></p>
            </footer>

        </div> <!-- /container -->
    </body>
</html>