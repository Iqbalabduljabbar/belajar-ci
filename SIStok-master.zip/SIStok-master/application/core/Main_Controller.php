<?php
class Main_Controller extends MY_Controller 
{
   function __construct()
   {
      parent::__construct();
   }
}
